﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace PizzariaSys.AcessoDados
{
    public class Contexto
    {
        private SqlConnection conexao;

        private SqlConnection CriarConexao(){
            conexao = new SqlConnection(ConfigurationManager.ConnectionStrings["strConexao"].ConnectionString);
            return conexao;
        }

        private SqlParameterCollection sqlParameterCollection = new SqlCommand().Parameters;

        private SqlCommand CriarComando(CommandType cmdType, string nomeProcedure) {
            conexao = CriarConexao();
            conexao.Open();
            SqlCommand cmd = conexao.CreateCommand();
            cmd.CommandType = cmdType;
            cmd.CommandText = nomeProcedure;
            cmd.CommandTimeout = 7200;
            foreach(SqlParameter sqlParameter in sqlParameterCollection){
                cmd.Parameters.Add(new SqlParameter(sqlParameter.ParameterName, sqlParameter.Value) );
            }
            return cmd;
        }

        protected void AdicionarParametros(string nomeParametro, object valorParametro) {
            sqlParameterCollection.Add(nomeParametro);
        }

        protected void LimparParametro() {
            sqlParameterCollection.Clear();
        }

        //FINALMENTE O QUE FAZ A PERSISTENCIA NO BANCO (INSERIR, ALTERAR, EXCLUIR)
        protected object ExecutarComando(CommandType cmdType, string nomeProcedure) {
            try
            {
                SqlCommand cmd = CriarComando(cmdType, nomeProcedure);
                return cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally {
                conexao.Close();
            }
        }

        //EXIBE OS DADOS (SELECT)
        protected DataTable ExecutarConsulta(CommandType cmdType, string nomeProcedure){
            try
            {
                SqlCommand cmd = CriarComando(cmdType, nomeProcedure);
                DataTable dt = new DataTable();
                SqlDataAdapter sqlDataAdapter = SqlDataAdapter(cmd);
                sqlDataAdapter.Fill(dt);
                return dt;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally {
                conexao.Close();
            }
        }

        private SqlDataAdapter SqlDataAdapter(SqlCommand cmd)
        {
            throw new NotImplementedException();
        }

    }
}
