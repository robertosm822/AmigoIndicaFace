﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzariaSys.AcessoDados.Interface
{   
    //criando o reposito onde o T eh uma classe de contrato
    public interface IRepositorio<T>where T:class{
        //todas as classes iram usar este modelo de metodos
        string Salvar(T entidade);
        string Deletar(T entidade);

        T BuscarId(int id);

        IEnumerable<T> ListarTodos();
    }
}
