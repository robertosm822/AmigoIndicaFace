﻿using PizzariaSys.AcessoDados.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzariaSys.Dominio.Interfaces
{
    public interface IClienteNegocios: IRepositorio<Cliente>
    {
        IEnumerable<Cliente> ListarClienteTelefone(string param);
    }
}
